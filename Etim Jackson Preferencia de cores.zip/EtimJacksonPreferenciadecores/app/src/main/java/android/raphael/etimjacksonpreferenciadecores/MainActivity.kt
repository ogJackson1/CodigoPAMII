package android.raphael.etimjacksonpreferenciadecores

import android.graphics.Color
import android.os.Bundle
import android.raphael.etimjacksonpreferenciadecores.databinding.ActivityMainBinding
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private  var cor = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnCor1.setOnClickListener(){

        }
        binding.btnCor2.setOnClickListener(){

        }
        binding.btnCor3.setOnClickListener(){

        }
        binding.btnCor4.setOnClickListener(){

        }
        binding.btnCor5.setOnClickListener(){

        }






    }
}